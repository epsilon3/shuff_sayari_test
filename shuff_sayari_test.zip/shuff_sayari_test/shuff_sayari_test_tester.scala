
import scala.xml.XML
import scala.collection.mutable.ListBuffer

var xmlSDN = XML.loadFile("SDN.xml")
var xmlConList = XML.loadFile("ConList.xml")
